package com.example.videoplayer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.pm.ActivityInfoCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements VideoRVAdapter.VideoClickInterface
{
//first create RecyclerView then for ArrayLsit and for videoRVAdapter//
    //after creating these variables first we create Recyclerview with its ID,Second ArrayList,3rd VideoRVAdapter//
    //start comment lines for permissions time 15:01//coding from 20:30//Done
    //here we also check the permissions from user
//
// for that, we will be asking the permissions to Read the users External Device(External Storage),//
// and also to ask weather the permissions are granted or not.//
    private RecyclerView videoRV;
    private ArrayList<VideoRVModal> videoRVModalArrayList;//
    private VideoRVAdapter videoRVAdapter;

    private static final int STORAGE_PERMISSION = 101;//first to ask storage permission we create intStorage in Variables.//
    // Along with this we have to add Permission in our Manifest, app>Manifest>(opened)Android.Manifest.xml>(add)//
    // "<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />"so that we will be able to read External Storage of User Device.//countinue-//
    // below package inside manifest//After this we Set VideoRVAdapter to RecyclerView which is in MainActivity.java folder//



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        videoRV = findViewById(R.id.idRVVideos); //1st creating recyclerview with its id//
        videoRVModalArrayList = new ArrayList<>();//2nd creating ArrayList//
        videoRVAdapter = new VideoRVAdapter(videoRVModalArrayList,this,this::onVideoClick); //3rd creating VideoRVAdapter. pass video modal, context, and
        // pass videoclickInterface for this we implement this method in mainactivity//
        //here we set VideoRVAdapter to RecyclerView for Permission of Users External Storage//
        videoRV.setLayoutManager(new GridLayoutManager(this,2));//For Permission first we set layoutmanager for recyclerview//
        //we use Grid Layout and inside it we pass 'this' with '2'(Indicates number of columns view) to get better view of video files in app//
        videoRV.setAdapter(videoRVAdapter);//after gridlayout we set Adapter Video to our RecyclerView//
        if(ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_DENIED)
        //here after setting Adapter Video to recyclerview we check if permissions are granted or not//
            // also we check if permissions are granted by user,//
            // if not then we make use of below request permission command by asking permission//
        {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE },STORAGE_PERMISSION);
            //inside request permission we pass the permission that we require for user by'MainActivity.this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE'. we are also passing the code//

        }else //in else condition the permissions are already granted therfore we just call getvideos//
        {
            getVideos();
        }
    }
    //form here we will be getting data from users device//
    //now to check when permission dialogs open by calling onrequestpermissionresult//
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    // inside OnRequestPermissionResult we will be checking by if and else condition that if weather permission is granted or not.//
    // if condition, if granted display following message and vice versa//
    // we use Toast command//
    //else condition, not granted display following message by using toast//
    // application closed by callling 'Finish()' because permission not granted//

    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==STORAGE_PERMISSION){   ///to request storage access to the users device///
             if(grantResults.length>0 && grantResults[0]== getPackageManager().PERMISSION_GRANTED)
        {
                Toast.makeText(this,"Permission Granted", Toast.LENGTH_SHORT).show(); //after this message we use getVideos//
                getVideos();
            }else
            {
                Toast.makeText(this, "The App will not work without permission..", Toast.LENGTH_SHORT).show();
                finish(); //we close our application by calling Finish//
            }
        }
    }

    private void getVideos()//after permissions we move to getvideos.inside here we use ContentResolver to get all the data from users Device//
    {
        ContentResolver contentResolver = getContentResolver(); //calling contentResolver, creating variable and use "getContentResolver()"//
        Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;//next after ContentResolver we create "Uri"//
        // After Creating we Have to Import this Uri//next creating cursor//

        Cursor cursor = contentResolver.query(uri, null, null, null, null);
        //in cursor we use If condition//
        if(cursor!=null && cursor.moveToFirst()) //in If condition we use Do and While Condition//
        {
            do{
                String videoTitle = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)); //for videoTitle//
                String videoPath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)); //for VideoPath//
                //for videoThumbnail use Bitmap//inside thumbnail we pass 'vieoPath, MediaStore.Image.Thubmnails' this is used to get the Thumbnails//
                // we can get different kinds.we use mini kind//Deprecated//
                Bitmap  videoThumbnail  = ThumbnailUtils.createVideoThumbnail(videoPath, MediaStore.Images.Thumbnails.MINI_KIND);///minikind deprecated///??????????????????/////
                //After geting Video Data we have to pass VideoArraylist//
                videoRVModalArrayList.add(new VideoRVModal(videoTitle,videoPath,videoThumbnail));  ///start from here23:31///Done
            }while(cursor.moveToNext());  //in while condition we move cursor to next position//
            }
        videoRVAdapter.notifyDataSetChanged(); //we call this to notify our RecyclerView, that the data inside our Adapeter is changed//
    } //we have completed calling all the data for users Device//
    // next on inside videoclick method//
    @Override
    public void onVideoClick(int position) //here we open new intent by first creating new activity by,//
    // app>(packageName) "com.example.videoplayer">rightclick>new>Activity>EmptyActivity>Specify the name as, "VideoPlayerActivity"(insdie this activity we play our video)>ok//Created "VideoPlayerActivity.java"(folder)//
    //next after creating folder, inside mainactivity.java we call INTENT//

     {
        Intent i = new Intent(MainActivity.this, VideoPlayerActivity.class); //call intent
        i.putExtra("videoName", videoRVModalArrayList.get(position).getVideoName()); //to pass data as pattern mentioned//
        i.putExtra("videoPath", videoRVModalArrayList.get(position).getVideoPath());// to pass videoPath//
        startActivity(i); //start activity//NEXT WE MOVE TOWARDS VIDEOPLAYERACTIVITY.Java which we created earlier//
    }
}


