package com.example.videoplayer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class VideoRVAdapter extends RecyclerView.Adapter<VideoRVAdapter.ViewHolder> {
//rightclcik on Viewholder>Implement Methods>Select All>ok //
// if error shown the create a inner class at error by rightclcik>create inner class'ViewHolder'//
   //after creating viewholder we create arraylist inside adapter class along with this we create Interface class//
private ArrayList<VideoRVModal> videoRVModalArrayList;
    private Context context; //creating VideoClickInterface//
    private VideoClickInterface videoClickInterface;
//creating constructor for all the above 3 variable by rightclcik>Generate>Constructor>Select All 3 variables>ok//
    public VideoRVAdapter(ArrayList<VideoRVModal> videoRVModalArrayList, Context context, VideoClickInterface videoClickInterface) {
        this.videoRVModalArrayList = videoRVModalArrayList;
        this.context = context;
        this.videoClickInterface = videoClickInterface; //Constructor Created//next go to onBindViewHolder//
    }

    @NonNull
    @Override //first we work on oncreateviewholder in this we implate the layout file ie VideoRVAdapter for each item of recyclerview//
    public VideoRVAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_rv_item,parent,false); //create view//
        return new ViewHolder(view); //return//
    }

    @Override
   //after creating constructor for VideoRVAdapter, here we are setting data to each Overview ie ImageView//
    //created after imageview to get data ie from arraylist Modal//
    public void onBindViewHolder(@NonNull VideoRVAdapter.ViewHolder holder, int position) {
        VideoRVModal videoRVModal = videoRVModalArrayList.get(position);//created after imageview to get data ie from arraylist Modal//
        holder.thumbnailIV.setImageBitmap(videoRVModal.getThumbNail());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override //inside onBindViewholder we call videoClickInterface//
            public void onClick(View v) {
                videoClickInterface.onVideoClick(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return videoRVModalArrayList.size();//here it was 0 from that we have ti enter the size of arraylist//
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView thumbnailIV;// creating imageview thumbnail first then videoRVMODAL//
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            thumbnailIV = itemView.findViewById(R.id.idIVThumbNail);
        }
    }

  //InterFace class created along arraylist//
    //we use this for on click action for each of our video by using onvideoclcik//
  public interface VideoClickInterface{
        void onVideoClick(int position); //onvideoclick//next create variable for arraylist as well//
    }
}
//Adapter Class completed, next we have to initialize this class in our MainActivity.java//